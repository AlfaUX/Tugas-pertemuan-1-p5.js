function setup() {
  createCanvas(640, 480);
}

function draw() {
  background('#b597f6');
}